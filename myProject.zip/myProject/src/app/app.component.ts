import { Component,OnInit } from '@angular/core';
import {HttpClient } from '@angular/common/http';
import { WeatherServiceService } from './weather-service.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{

  title = 'myProject';
  public data:any=[];
  public weatherData:any;
  public tempData:any;
  public location:any;
  public connect_url:any=[]
  constructor(private ws:WeatherServiceService)
  {
  }

  ngOnInit(): void {
    this.data=this.ws.getData().subscribe((response:any)=>{
    this.data = response;
    console.log(this.data.weather);
    this.weatherData=this.data.weather;
    this.tempData=this.data.main;
    console.log(this.tempData) 
    this.location=this.data; 
    })
      
  }
}
