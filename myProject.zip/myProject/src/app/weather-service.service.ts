import { Injectable } from  '@angular/core' ;
import { HttpClient,HttpErrorResponse,HttpHeaders } from '@angular/common/http' ;
import { catchError,map, timeout} from 'rxjs/operators' ;

import { Observable,of,throwError } from 'rxjs';

@Injectable ({
    providedIn: 'root'
})

export class WeatherServiceService {
    public data:any;

    public weatherData:any;

    public errorMsg!: string;
    constructor (private httpClient:HttpClient) { }

    private getUrl():string {
        return 'https://api.openweathermap.org/data/2.5/weather?q=Boston%20&appid=01d98b3db2d95380b11619bfa3749572&units=imperial'

    }
    getData() :Observable<any>
    {
        const headers = new HttpHeaders({
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'appid': '01d98b3db2d95380b11619bfa3749572',
         
        });

        return this.httpClient.get<any> (
         this.getUrl(),
         {
          headers,
          responseType: "json", 
          withCredentials:true
         }

        ).pipe(timeout(90000),map((res:any) => {
            var resp = res;
            console.log(resp);
            return resp;
        }),catchError(this.handleError));
        
    }
    private handleError(error:HttpErrorResponse) {
        let err=error;
        if(error.error instanceof ErrorEvent){

        }else{
            if(error.status!==0){

            }else{

            }
        }
        return throwError(error);
    }
 }
    